<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Team 8</title>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="drop.css" rel="stylesheet" type="text/css" />
<!--[if IE 5]>
<style type="text/css"> 
/* place css box model fixes for IE 5* in this conditional comment */
#sidebar1 { width: 230px; }
</style>
<![endif]--><!--[if IE]>
<style type="text/css"> 
/* place css fixes for all versions of IE in this conditional comment */
#sidebar1 { padding-top: 30px; }
#mainContent { zoom: 1; }
/* the above proprietary zoom property gives IE the hasLayout it needs to avoid several bugs */
</style>
<![endif]-->
</head>
<body>
<!-- begin #container -->
<div id="container">
	<!-- begin #header -->
    <div id="header">
		<div class="headerTop">
        	<div class="logo">
            	<a href=""><img src="images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a>Team 8 <span>Hospital Management System</span>
            </div>
            <div class="search">
            Doctor Portal
             </div>
            </div>
      	</div>
        <div class="mainMenu">
        <ul class="menuTemplate1 decor1_1" license="mylicense">
    <li class="separator"></li>
 	
		<li><a href="doctor.php" class="arrow">Back</a>
    
			
			 
            
 
</ul>
        </div>
        
<html>
<body>
<?php
//include('config.php');
session_start();
require 'doctorSession.php';
require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
// $query=mysql_connect("localhost","root","root");
// mysql_select_db("hospital",$query);
if(isset($_GET['Edit']))
{
$PatientID=$_GET['Edit'];
//echo $PatientID;

$FinedPatientName = mysqli_query($connection,"SELECT * FROM patient WHERE PatientID = '$PatientID'");
 $row = mysqli_fetch_array($FinedPatientName,MYSQLI_ASSOC);
   
 $PatientFname = $row['Fname'];
 $PatientLname = $row['Lname'];

$_SESSION['PatientID'] = $PatientID;
if(isset($_POST['submit']))
{
$BloodType=$_POST['BloodType'];
$Weight=$_POST['Weight'];
$Height=$_POST['Height'];
$Vitals=$_POST['Vitals'];
$query3=mysqli_query($connection, "update patient set BloodType='$BloodType', Weight='$Weight' , Height='$Height'  , Vitals='$Vitals'  where PatientID='$PatientID'");
if($query3)
{
header('location:doctor.php');
}
}
$query1=mysqli_query($connection, "select * from patient where PatientID='$PatientID'");
$query2=mysqli_fetch_array($query1);
?>
<form method="post" action="">
Blood Type:<input type="text" name="BloodType" value="<?php echo $query2['BloodType']; ?>" /><br /><br />
Weight:<input type="text" name="Weight" value="<?php echo $query2['Weight']; ?>" /><br /><br />
Height:<input type="text" name="Height" value="<?php echo $query2['Height']; ?>" /><br /><br />
Vitals:<input type="text" name="Vitals" value="<?php echo $query2['Vitals']; ?>" /><br /><br />
<br />
<input type="submit" name="submit" value="update" />
</form>
<?php
}
?>
</body>
</html>