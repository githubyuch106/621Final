<?php
//Make sure page cant be accessed without logging in
    if(!isset($_SESSION['Admin'])) {
        session_destroy();
        echo "<script  type='text/javascript'>
                    alert('Access Denied. Please Sign in as an Admin.');
                </script>";
        header("Location: newindex.html");
    }
 ?>