<?php
session_start();
require 'doctorSession.php';
require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_GET['Delete']))
{
	
	$ReportID = $_GET['Delete'];
	
	$que1 = " DELETE FROM medicine WHERE ReportID = '$ReportID'";
	$que =  " DELETE FROM `report` WHERE ReportID = '$ReportID'";
    $record = mysqli_query($connection,$que)  or print(mysql_error());
	echo "<meta http-equiv='refresh' content = '0;url=doctor.php'>"; 

}

//iterate over all the rows
if($record === FALSE){

echo $record;

}



?>