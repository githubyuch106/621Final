<?php
session_start();
require 'adminSession.php';
?>
<!DOCTYPE html>
<html>
<!-- 
<div class="logo">
            	<a href=""><img src="/621Final/images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a> Team 8<br><span>Hospital Database Management</span>
            	
            </div>
<style>
.logo {
	margin-left: 0px;
	margin-top: 10px;
	padding-left: 5px;
	padding-right:5px;
	border-radius: 10px;
	background-color: #98B8F3;	
	margin-right: 50px;
	}
.body{
margin-left: 50px;
}
</style>
 -->
 <title>Team 8</title>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="drop.css" rel="stylesheet" type="text/css" />
<!--[if IE 5]>
<style type="text/css"> 
/* place css box model fixes for IE 5* in this conditional comment */
#sidebar1 { width: 230px; }
</style>
<![endif]--><!--[if IE]>
<style type="text/css"> 
/* place css fixes for all versions of IE in this conditional comment */
#sidebar1 { padding-top: 30px; }
#mainContent { zoom: 1; }
/* the above proprietary zoom property gives IE the hasLayout it needs to avoid several bugs */
</style>
<![endif]-->
</head>
<body>
<!-- begin #container -->
<div id="container">
	<!-- begin #header -->
    <div id="header">
		<div class="headerTop">
        	<div class="logo">
            	<a href=""><img src="images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a>Team 8 <span>Hospital Management System</span>
            </div>
            <div class="search">
            Admin Portal
             </div>
            </div>
      	</div>
        <div class="mainMenu">
        <ul class="menuTemplate1 decor1_1" license="mylicense">
    <li class="separator"></li>
    <li><a href="#Horizontal-Menus" class="arrow">Employee</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListEmployee.php">List Employees</a><br />
                    <a href="addEmployeeForm.php">Add Employee</a><br />
                </div>
            </div>
			
			
			
			
			    <li><a href="#Horizontal-Menus" class="arrow">Patient</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListPatient.php">List Patients</a><br />
                    <a href="addPatient.html">Add Patient</a><br />
                </div>
            </div>
			
			
			
			
				    <li><a href="#Horizontal-Menus" class="arrow">Room</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListRoom.php">List Rooms</a><br />
                    <a href="addRoomForm.php">Add Room</a><br />
					<a href="OccupiedRoom.php">Room Occupied</a><br />
					<a href="RoomsStatus.php">Room Status</a><br />
                </div>
            </div>
			
			
			
			
						    <li><a href="#Horizontal-Menus" class="arrow">Job Title</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListJobTitle.php">List Job Title</a><br />
					<a href="AdminAddJobTitleForm.php">Add Job Title </a><br />
                </div>
            </div>
			
			<li><a href="#Horizontal-Menus" class="arrow">Search</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminSearch.php">Search For Users</a><br/>
                </div>
        </div>	
			
			
		<li><a href="logout.php" class="arrow">Logout</a>
    
			
			 
            
 
</ul>
        </div>
<body class = "body">

<h2>New Employee</h2>
<br>
<form  method = "POST" action="addEmployee.php" enctype="multipart/form-data">


  <div class="container">


    <label><b>SSN</b></label>
    <input type="text" placeholder="Enter SSN" name="SSN" required>
<br></br>


    <label><b>First Name</b></label>
    <input type="text" placeholder="Enter First Name" name="Fname" required>
        <br></br>
		
		
    <label><b>Last name</b></label>
    <input type="text" placeholder="Enter Last Name" name="Lname" required>
        <br></br>


				
    <label><b>Phone Number</b></label>
    <input type="text" placeholder="Enter Phone Number" name="PhoneNumber" required>
        <br></br>
		
		
    <label><b>Salary </b></label>
    <input type="text" placeholder="Enter Salary" name="Salary" required>
        <br></br>
		
		<?php
//		session_start();
require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
} ?>


            <label><b>Job Title</b></label>
            <select name = "JobTitle" id="JobTitle">
                <option>Job Title</option>
                <?php
                if($stmt=$connection->query("select position from jobtitle"))
                {
                    while($r=$stmt->fetch_array(MYSQLI_ASSOC))
                    {
                 ?>      
                <option name = "JobTitle" value="<?php echo $r['position'] ?>"><?php echo $r['position'] ?></option> 
                
                <?php  }  }   ?>
                
            </select>
	
		<br></br>

	<!--	
    <label><b>Job Title</b></label>
    <input type="text" placeholder="Enter Job Title" name="JobTitle" required>
        <br></br>
		-->
		<label><b>Email</b></label>
    <input type="email" placeholder="Enter Email" name="Email" required>
        <br></br>
		
			<label><b>Security Question</b></label>
    <input type="text" placeholder="Enter security question" name="SecurityQuestion" required>
        <br></br>

	<label><b>Security Answer</b></label>
    <input type="text" placeholder="Enter security answer" name="SecurityAnswer" required>
        <br></br>
		
			 <label><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="Password" required>
        <br></br>
		
		 <label><b>Image</b></label>
    <input type="file"  name="image" required>
	<br></br>
	
	
		
		
    <button type="submit">Save</button>
	<br></br>
  </div>
  
	
 
</form>


 
</form>


</body>
</html>

