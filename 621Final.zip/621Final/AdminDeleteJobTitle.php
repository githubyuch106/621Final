<?php
session_start();
require 'adminSession.php';
  	require 'common.php';
		$connection = new mysqli($localhost , $dusername , $dpassword,$database);
		if ($connection->connect_error) {
		    die("Connection failed: " . $conn->connect_error);
			echo "No Connection to DB";
		} 

if (isset($_GET['Delete']))
{
	
	$ID = $_GET['Delete'];
	
	
	$que =  " DELETE FROM `jobtitle` WHERE ID = '$ID'";
    $record = mysqli_query($connection, $que) or print(mysql_error());
	echo "<meta http-equiv='refresh' content = '0;url=AdminListJobTitle.php'>"; 

}

//iterate over all the rows
if($record === FALSE){

echo $record;

}



?>