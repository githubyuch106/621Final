<?php
session_start();
require 'adminSession.php';
?>

<html>
<body>
<title>Team 8</title>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="drop.css" rel="stylesheet" type="text/css" />
<!--[if IE 5]>
<style type="text/css"> 
/* place css box model fixes for IE 5* in this conditional comment */
#sidebar1 { width: 230px; }
</style>
<![endif]--><!--[if IE]>
<style type="text/css"> 
/* place css fixes for all versions of IE in this conditional comment */
#sidebar1 { padding-top: 30px; }
#mainContent { zoom: 1; }
/* the above proprietary zoom property gives IE the hasLayout it needs to avoid several bugs */
</style>
<![endif]-->
</head>
<body>
<!-- begin #container -->
<div id="container">
	<!-- begin #header -->
    <div id="header">
		<div class="headerTop">
        	<div class="logo">
            	<a href=""><img src="images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a>Team 8 <span>Hospital Management System</span>
            </div>
            <div class="search">
            Admin Portal
             </div>
            </div>
      	</div>
        <div class="mainMenu">
        <ul class="menuTemplate1 decor1_1" license="mylicense">
    <li class="separator"></li>
    <li><a href="#Horizontal-Menus" class="arrow">Employee</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListEmployee.php">List Employees</a><br />
                    <a href="addEmployeeForm.php">Add Employee</a><br />
                </div>
            </div>
			
			
			
			
			    <li><a href="#Horizontal-Menus" class="arrow">Patient</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListPatient.php">List Patients</a><br />
                    <a href="addPatient.html">Add Patient</a><br />
                </div>
            </div>
			
			
			
			
				    <li><a href="#Horizontal-Menus" class="arrow">Room</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListRoom.php">List Rooms</a><br />
                    <a href="addRoomForm.php">Add Room</a><br />
					<a href="OccupiedRoom.php">Room Occupied</a><br />
					<a href="RoomsStatus.php">Room Status</a><br />
                </div>
            </div>
			
			
			
			
						    <li><a href="#Horizontal-Menus" class="arrow">Job Title</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListJobTitle.php">List Job Title</a><br />
					<a href="AdminAddJobTitleForm.php">Add Job Title </a><br />
                </div>
            </div>
			
			<li><a href="#Horizontal-Menus" class="arrow">Search</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminSearch.php">Search For Users</a><br/>
                </div>
        </div>	
			
			
		<li><a href="logout.php" class="arrow">Logout</a>
    
			
			 
            
 
</ul>
        </div>
<br />
<!-- 
<form action="admin.php">
    <input type = "image" value="Main Page" src = "images/Home.png" width="66" height="66"/>
</form>
 -->
 <div class ="newbody">
<?php

echo '<link href="style1.css" rel="stylesheet">';
require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	echo "No Connection to DB";
} 
//echo "Connected successfully";
echo "<pre>";

//$aEmpID = $_SESSION['aEmpID'];
//echo $aEmpID;
echo "<pre>";
 
	 $quiry = "SELECT * from patient";

	 $result = mysqli_query($connection, $quiry);
//echo $result;
echo "<pre>";
if (!$result)
{
	
    die("Query Faile".  mysqli_errno($connection));   
}

if ($result->num_rows > 0) {
    // output data of each row
	echo "<table class='zui-table zui-table-zebra zui-table-horizontal' align= 'center'>";
	
	   echo "<tr>";
	   echo "<td>PatientID</td>";
	   echo "<td>Image</td>";
       echo "<td>First Name</td>";
	   echo "<td>Last Name</td>";
	   echo "<td>Address</td>";
	   echo "<td>BloodType</td>";
	   echo "<td>Sex</td>";
	   echo "<td>Weight</td>";
	   echo "<td>Height</td>";
	   echo "<td>Vitals</td>";
		echo "</tr>";
    while($row = $result->fetch_assoc()) {
	   $PatientID = $row['PatientID'];
       $Fname =  $row['Fname'];
	   $Lname =  $row['Lname'];
	   $Address =  $row['Address'];
	   $BloodType =  $row['BloodType'];
	   $Sex =  $row['Sex'];
	   $Weight =  $row['Weight'];
	   $Height =  $row['Height'];
	   $Vitals =  $row['Vitals'];
	   $image = '<img src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'" height="100" width="100"/>';

		
       echo "<tr>";
       echo "<td>$PatientID</td>";
	   echo "<td>$image</td>";
       echo "<td>$Fname</td>";
	   echo "<td>$Lname</td>";
	   echo "<td>$Address</td>";
	   echo "<td>$BloodType</td>";
	   echo "<td>$Sex</td>";
	   echo "<td>$Weight</td>";
	   echo "<td>$Height</td>";
	   echo "<td>$Vitals</td>";
	   echo "<td colspan='2'>". "<a href = 'AdminEditPatient.php?Edit=$row[PatientID]'>Edit</a>".  "</td>";
	   echo "<td colspan='2'>". "<a href = 'AdminDeletePatient.php?Delete=$row[PatientID]'>Delete</a>".  "</td>";
	   //echo "<br>";
	   echo "</tr>";
		
    }
} else {
	
		echo "There is no patients";
		//header("location:regist.html");

    //echo "0 results";
	echo "</table>";
}







?>
</div>
<style>
.newbody{
background: white;
padding-bottom: 00px;
}
</style>
</body>
</html>