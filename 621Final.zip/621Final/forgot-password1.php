<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="style1111.css">
<div class="logo">
            	<a href=""><img src="/621Final/images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a> Team 8<br><span>Hospital Database Management</span>
            	
            </div>
<style>
.logo {
	margin-left: 0px;
	margin-top: 10px;
	padding-left: 5px;
	padding-right:5px;
	border-radius: 10px;
	background-color: #98B8F3;	
	margin-right: 50px;
	}
.body{
margin-left: 50px;
}
</style>
</head>
<body>
<form method="POST" action="forgot-password2.php">
<p><label>ID</label> <input type="text" name="id"></p>
<p><input type="radio" value="employee" name="member-type"> <label>Employee</label></p>
<p><input type="radio" value="patient" name="member-type"> <label>Patient</label></p>
<p><input type="submit" value="Answer security question and reset password"></p>
</form>
</form>
<form action="newindex.html">
    <input type="submit" value="back" />
</form>
</body>
</html>
