<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Team 8</title>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="drop.css" rel="stylesheet" type="text/css" />

</head>
<body>

<!-- begin #container -->
<div id="container">
	<!-- begin #header -->
    <div id="header">
		<div class="headerTop">
        	<div class="logo">
            	<a href=""><img src="images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a>Team 8 <span>Hospital Management System</span>
            </div>
            <div class="search">
            Doctor Portal
             </div>
            </div>
      	</div>
        <div class="mainMenu">
        <ul class="menuTemplate1 decor1_1" license="mylicense">
    <li class="separator"></li>
 	
		<li><a href="doctor.php" class="arrow">Back</a>
    
</ul>
        </div>
<?php
//include('config.php');
session_start();
require 'doctorSession.php';
require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_GET['Edit']))
{
$MedicineID=$_GET['Edit'];
echo $MedicineID;
$_SESSION['MedicineID'] = $MedicineID;
if(isset($_POST['submit']))
{
$Treatment=$_POST['Treatment'];
$query3=mysqli_query($connection,"update medicine set Treatment='$Treatment' where MedicineID='$MedicineID'");
if($query3)
{
header('location:doctor.php');
}
}
$query1=mysqli_query($connection,"select * from medicine where MedicineID='$MedicineID'");
$query2=mysqli_fetch_array($query1);
?>
<form method="post" action="">
Treatment:<input type="text" name="Treatment" value="<?php echo $query2['Treatment']; ?>" /><br /><br />

<br />
<input type="submit" name="submit" value="update" />
</form>
<?php
}
?>
</body>
</html>