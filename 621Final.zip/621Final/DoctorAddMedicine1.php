<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Team 8</title>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="drop.css" rel="stylesheet" type="text/css" />

</head>
<body>

<!-- begin #container -->
<div id="container">
	<!-- begin #header -->
    <div id="header">
		<div class="headerTop">
        	<div class="logo">
            	<a href=""><img src="images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a>Team 8 <span>Hospital Management System</span>
            </div>
            <div class="search">
            Doctor Portal
             </div>
            </div>
      	</div>
        <div class="mainMenu">
        <ul class="menuTemplate1 decor1_1" license="mylicense">
    <li class="separator"></li>
 	
		<li><a href="doctor.php" class="arrow">Back</a>
    
</ul>
        </div>
        
<?php 
session_start();
require 'doctorSession.php';
$ReportID=$_GET['Medicine'];
//echo $PatientID; 
$_SESSION['ReportID'] = $ReportID;
//echo $PatientID;
?>
<div class="newbody">
<h2>New Medicine</h2>
<form  method = "POST" action="DoctorAddMedicine.php">
  <div class="container">
      <label><b>Report</b></label>
    <textarea type="text" placeholder="Write Medicine" name="Treatment" style = "width: 400px" required> </textarea>
        <br></br>
    <button type="submit">Save</button>
	<br></br>
  </div>
</form>


<?php
//session_start();
require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$_SESSION['ReportID'] = $ReportID;
	 $quiry = "SELECT  * from medicine where ReportID = '$ReportID'";

	 $result = mysqli_query($connection, $quiry);
//echo $result;
echo "<pre>";
if (!$result)
{
	
    die("Query Faile".  mysqli_errno($connection));   
}

if ($result->num_rows > 0) {
    // output data of each row
	echo "<table align='left' width='20%' height='20%'>";
	   echo "<tr>";
	   echo "<td>Treatment</td>";
		echo "</tr>";
    while($row = $result->fetch_assoc()) {
	   $Treatment = $row['Treatment'];
       echo "<tr>";
       echo "<td>$Treatment</td>";
	   echo "<td colspan='2'>". "<a href = 'DoctorEditMedicine.php?Edit=$row[MedicineID]'>Edit </a>".  "</td>";
	    echo "<td colspan='2'>". "<a href = 'DoctorDeleteMedicine.php?Delete=$row[MedicineID]'>Delete</a>".  "</td>";
	   //echo "<br>";
	   echo "</tr>";
		
    }
} else {
	
		echo "There is no report";
		//header("location:regist.html");

    //echo "0 results";
	echo "</table>";
}

?>
</div>

<style>
.newbody{
padding-bottom: 300px;

}
</style>
</body>
</html>

