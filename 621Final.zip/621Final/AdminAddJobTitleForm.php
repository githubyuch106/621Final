<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Team 8</title>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="drop.css" rel="stylesheet" type="text/css" />
<!--[if IE 5]>
<style type="text/css"> 
/* place css box model fixes for IE 5* in this conditional comment */
#sidebar1 { width: 230px; }
</style>
<![endif]--><!--[if IE]>
<style type="text/css"> 
/* place css fixes for all versions of IE in this conditional comment */
#sidebar1 { padding-top: 30px; }
#mainContent { zoom: 1; }
/* the above proprietary zoom property gives IE the hasLayout it needs to avoid several bugs */
</style>
<![endif]-->
</head>
<body>
<!-- begin #container -->
<div id="container">
	<!-- begin #header -->
    <div id="header">
		<div class="headerTop">
        	<div class="logo">
            	<a href=""><img src="images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a>Team 8 <span>Hospital Management System</span>
            </div>
            <div class="search">
            Admin Portal
             </div>
            </div>
      	</div>
        <div class="mainMenu">
        <ul class="menuTemplate1 decor1_1" license="mylicense">
    <li class="separator"></li>
    <li><a href="#Horizontal-Menus" class="arrow">Employee</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListEmployee.php">List Employees</a><br />
                    <a href="addEmployeeForm.php">Add Employee</a><br />
                </div>
            </div>
			
			
			
			
			    <li><a href="#Horizontal-Menus" class="arrow">Patient</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListPatient.php">List Patients</a><br />
                    <a href="addPatient.html">Add Patient</a><br />
                </div>
            </div>
			
			
			
			
				    <li><a href="#Horizontal-Menus" class="arrow">Room</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListRoom.php">List Rooms</a><br />
                    <a href="addRoomForm.php">Add Room</a><br />
					<a href="OccupiedRoom.php">Room Occupied</a><br />
					<a href="RoomsStatus.php">Room Status</a><br />
                </div>
            </div>
			
			
			
			
						    <li><a href="#Horizontal-Menus" class="arrow">Job Title</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminListJobTitle.php">List Job Title</a><br />
					<a href="AdminAddJobTitleForm.php">Add Job Title </a><br />
                </div>
            </div>
			
			<li><a href="#Horizontal-Menus" class="arrow">Search</a>
        <div class="drop decor1_2" style="width: 150px;">
            <div class='left'>
                <div>
                    <a href="AdminSearch.php">Search For Users</a><br/>
                </div>
        </div>	
			
			
		<li><a href="logout.php" class="arrow">Logout</a>
    
			
			 
            
 
</ul>
        </div>
<?php
session_start();
require 'adminSession.php';
?>

<?php

?>

<!DOCTYPE html>
<html>

<body>

<h2>New Job Title</h2>

<form  method = "POST" action="AdminAddJobTitle.php" enctype="multipart/form-data">


  <div class="container">
  

    <label><b>Job Title</b></label>
    <input type="text" placeholder="Enter New Job Title" name="JobTitle" required>
        <br></br>

		
		
		
    <button type="submit">Save</button>
	<br></br>
  </div>
  
	
 
</form>




</body>
</html>

