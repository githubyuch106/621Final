<?php
echo "Welcome for register";

header( "refresh:5;url=newindex.html" );

?>
