<?php
	session_start();
    require 'doctorSession.php';
?>
<html>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="drop.css" rel="stylesheet" type="text/css" />
<body>
<div id="container">
	<!-- begin #header -->
    <div id="header">
		<div class="headerTop">
        	<div class="logo">
            	<a href=""><img src="images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a>Team 8 <span>Hospital Management System</span>
            	
            </div>
            
            <div class="search">
            Doctor Portal
            
<?php
//session_start();
require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	echo "No Connection to DB";
} 
echo "<pre>";

$aEmpID = $_SESSION['aEmpID'];
//echo $aEmpID;

$FineEmpName = mysqli_query($connection,"SELECT Fname , Lname FROM employee WHERE EmpID = '$aEmpID'");
 $row = mysqli_fetch_array($FineEmpName,MYSQLI_ASSOC);
   
 $EmpFname = $row['Fname'];
 $EmpLname = $row['Lname'];
   
   echo "Dr. ";
   echo $EmpFname;
   echo " ";
   echo $EmpLname;
   
?>
             </div>
            </div>
      	</div>
      	<div class="mainMenu">
        <ul class="menuTemplate1 decor1_1" license="mylicense">
    <li class="separator"></li>
    <!-- 
<li><a href="patientProfile.php" class="arrow">Profile</a>
       <li><a href = "patientReport.php" class = "arrow">Report</a>
 -->
     <li><a href="#Horizontal-Menus" class="arrow">Settings</a>
			        <div class="drop decor1_2" style="width: 150px;">
			            <div class='left'>
			                <div>
			                    <a href="setting.php">Change Password</a><br/>
			                    <a href="EditDoctor.php">Edit Doctor Info</a><br/>
			                </div>
			            </div>
			            <li><a href="searchpatient.php" class = "arrow">Search</a>
		<li><a href="logout.php" class="arrow">Logout</a>
 
</ul>
        </div>
        <div class="headerPic">


<style>
.headerPic{
background: white;
}
</style> 
   <h1 class = "h1 " align = "center">  <?php
//session_start();
require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	echo "No Connection to DB";
} 
echo "<pre>";

$aEmpID = $_SESSION['aEmpID'];
//echo $aEmpID;

$FineEmpName = mysqli_query($connection,"SELECT Fname , Lname FROM employee WHERE EmpID = '$aEmpID'");
 $row = mysqli_fetch_array($FineEmpName,MYSQLI_ASSOC);
   
 $EmpFname = $row['Fname'];
 $EmpLname = $row['Lname'];
   
   echo "Welcome Dr. ";
   echo $EmpFname;
   echo " ";
   echo $EmpLname;
   
?></h1>
        <style>
        .h1{
        margin-top: 30px;
        font-size: 40pt;
        
        }
        
        </style>
 <center>
       <img src="images/Saint_Joseph's_University_seal.png" alt="" width="90" height="90"/>
       </center>
 <!-- 
  <script  type="text/javascript" >
            var xmlhttp = new XMLHttpRequest();
            
            xmlhttp.onreadystatechange=function() {
                       //*** response is ready
                       if ((xmlhttp.readyState == 4) && (xmlhttp.status == 200)) {
                            document.getElementById("patientTable").innerHTML = xmlhttp.responseText;
                       }
             }   
             function ajaxFunction() {
                  var URL = "http://localhost/621Final/doctorTable.php";
                  var queryString = "searchBy=" + document.getElementById("searchBy").value +"&search="+ document.getElementById("search").value;
                  xmlhttp.open("POST", URL, true);
                  xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                  xmlhttp.send(queryString);
              }
        </script>


     <form name="PaitentTableFrom">

            <input type="text" id="search" placeholder="Search for Patients" onKeyUp="ajaxFunction()"/>
            
            <select id="searchBy">
                <option value="Fname">First Name</option>
                <option value="Lname">Last Name</option>
                <option value="Bloodtype">Bloodtype</option>
                <option value="Sex">Sex</option>
                <option value="Weight">Weight</option>
                <option value="Height">Height</option>
                <option value="Vitals">Vitals</option>
            </select> 
            
        </form>
         <div class="table" id="patientTable">
        </div>

    </div>
 -->
    <!-- end #header -->
	<form  method = "POST" action="direct.php">
    <div class="allContent">
   
<div class = "doctorReport">

</div>
</body>
<div id="newfooter" align = "center">
    	<p>
        	Copyright &copy; 2016. Designed by Team 8<br />
       </p>
       </div>
       <style>
       #newfooter{
       padding-top: 200px;
       
       }
       </style>

</html>
