<html>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="drop.css" rel="stylesheet" type="text/css" />
<body>
<div id="container">
	<!-- begin #header -->
    <div id="header">
		<div class="headerTop">
        	<div class="logo">
            	<a href=""><img src="images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a>Team 8 <span>Hospital Management System</span>
            	
            </div>
            
            <div class="search">
            Patient Portal

             </div>
            </div>
      	</div>
      	<div class="mainMenu">
        <ul class="menuTemplate1 decor1_1" license="mylicense">
    <li class="separator"></li>
    <li><a href="patientProfile.php" class="arrow">Profile</a>
       <li><a href = "patientReport.php" class = "arrow">Report</a>
       <li><a href = "patientAppt.php" class = "arrow">Appointment</a>
		<li><a href="logout.php" class="arrow">Logout</a>
   		  
</ul>
        </div>
<?php
    session_start();
    require 'patientSession.php';
 ?>

<?php

require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	echo "No Connection to DB";
} 

function minute_to_time($min) {
	$hour = floor($min / 60);
	$postmark = $hour >= 12 ? 'PM' : 'AM';
	$hour = $hour % 12;
	if ($hour == 0) {
		$hour = 12;
	}

	return sprintf("%d:%02d %s", $hour, $min % 60, $postmark);
}

$id = $_SESSION['PatientID'];
?>
<h2>Appointments</h2>
<?php
$q = $connection->prepare('SELECT VisitID, UNIX_TIMESTAMP(Time), Lname FROM appointment JOIN employee USING (EmpID) WHERE PatientID = ?');
$q->bind_param('s', $id);
$q->execute();
$q->bind_result($appt_id, $time, $dr_name);
?>
<form method="POST" action="cancel-appointment.php">
<table>
<thead>
<tr><th></th><th>Date/Time</th><th>Doctor</th></tr>
</thead>
<tbody>
<?php while ($q->fetch()): ?>
<tr><td><input type="radio" name="appt_id" value="<?= $appt_id ?>"></td><td><?= date('j F Y g:i a', $time) ?></td><td>Dr. <?= $dr_name ?></td></tr>
<?php endwhile ?>
</tbody>
</table>
<p><input type="submit" value="Canel" width="50px" height="20px"></p>
</form>

<h2>Create Appointment</h2>
<?php
$q = $connection->prepare('SELECT EmpID, Lname FROM employee WHERE JobTitle = \'Doctor\'');
$q->execute();
$q->bind_result($id, $lname);
?>
<form method="POST" action="create-appointment.php">
<p><label>Date:</label> <input type="text" name="Date"></p>
<p><label>Time:</label> <select name="Time">
<?php for ($minute = 60*8; $minute <= 60*19; $minute += 30): ?>
	<option value="<?= $minute*60 ?>"><?= minute_to_time($minute) ?></option>
<?php endfor ?>
</select></p>
<p><label>Doctor: <select name="EmpID">
<?php while ($q->fetch()): ?>
<option value="<?= $id ?>">Dr. <?= $lname ?></option>
<?php endwhile ?>
</select></p>
<p><input type="submit" value="Make Appointment" width="100px" height = "40px"></p>
</form>
