<?php
session_start();
require 'doctorSession.php';

require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_GET['Delete']))
{
	
	$MedicineID = $_GET['Delete'];
	
	
	$que =  " DELETE FROM medicine WHERE MedicineID = '$MedicineID'";
    $record = mysqli_query($connection,$que) or print(mysql_error());
	echo "<meta http-equiv='refresh' content = '0;url=Doctor.php'>"; 

}

//iterate over all the rows
if($record === FALSE){

echo $record;

}



?>