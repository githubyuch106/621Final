<?php
session_start();
require 'patientSession.php';
?>
<div class="logo">
            	<a href=""><img src="/621Final/images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a> Team 8<br><span>Hospital Database Management</span>
            	
            </div>
<style>
.logo {
	margin-left: 0px;
	margin-top: 10px;
	padding-left: 5px;
	padding-right:5px;
	border-radius: 10px;
	background-color: #98B8F3;	
	margin-right: 50px;
	}
.body{
margin-left: 50px;
}
</style>

 
 <html>
<!-- 
<link href="styles.css" rel="stylesheet" type="text/css" />
<link href="drop.css" rel="stylesheet" type="text/css" />
<body>
<div id="container">
	<!~~ begin #header ~~>
    <div id="header">
		<div class="headerTop">
        	<div class="logo">
            	<a href=""><img src="images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a>Team 8 <span>Hospital Management System</span>
            	
            </div>
            
 -->
   <!-- 
         <div class="search">
            Patient Portal

             </div>
            </div>
      	</div>
      		<div class="mainMenu">
        <ul class="menuTemplate1 decor1_1" license="mylicense">
    <li class="separator"></li>
    <li><a href="patientProfile.php" class="arrow">Profile</a>
       <li><a href = "patientReport.php" class = "arrow">Report</a>
       <li><a href = "patientAppt.php" class = "arrow">Appointment</a>
		<li><a href="logout.php" class="arrow">Logout</a>
    
			
			 
            
 
</ul>
        </div>
 -->
<?php
//session_start();
?>
<html>
<body>
<br>
<form action="patient.php">
    <input type="submit" value="Main Page" />
</form>

<?php

require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	echo "No Connection to DB";
} 
//echo "Connected successfully";
echo "<pre>";
$PatientID = $_SESSION['PatientID'];
//echo $PatientID;
echo "<pre>";
 
	 $quiry = "SELECT * from patient WHERE PatientID = '$PatientID'";

	 $result = mysqli_query($connection, $quiry);
//echo $result;
echo "<pre>";
if (!$result)
{
	
    die("Query Faile".  mysqli_errno($connection));   
}

if ($result->num_rows > 0) {
    // output data of each row
	echo "<table align='left' width='20%' height='20%'>";
	
	   echo "<tr>";
	   echo "<td>PatientID</td>";
	   echo "<td>Image</td>";
       echo "<td>First Name</td>";
	   echo "<td>Last Name</td>";
	   echo "<td>Address</td>";
	   echo "<td>BloodType</td>";
	   echo "<td>Sex</td>";
	   echo "<td>Weight</td>";
	   echo "<td>Height</td>";
	   echo "<td>Vitals</td>";
		echo "</tr>";
    while($row = $result->fetch_assoc()) {
	   $PatientID = $row['PatientID'];
       $Fname =  $row['Fname'];
	   $Lname =  $row['Lname'];
	   $Address =  $row['Address'];
	   $BloodType =  $row['BloodType'];
	   $Sex =  $row['Sex'];
	   $Weight =  $row['Weight'];
	   $Height =  $row['Height'];
	   $Vitals =  $row['Vitals'];
	   $image = '<img src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'" height="200" width="200"/>';

		
       echo "<tr>";
       echo "<td>$PatientID</td>";
	   echo "<td>$image</td>";
       echo "<td>$Fname</td>";
	   echo "<td>$Lname</td>";
	   echo "<td>$Address</td>";
	   echo "<td>$BloodType</td>";
	   echo "<td>$Sex</td>";
	   echo "<td>$Weight</td>";
	   echo "<td>$Height</td>";
	   echo "<td>$Vitals</td>";
       echo "<td colspan='2'>". "<a href = 'patientEditSelf.php?Edit=$row[PatientID]'>Edit</a>".  "</td>";
	   //echo "<br>";
	   echo "</tr>";
		
    }
} else {
	
		
    //echo "0 results";
	echo "</table>";
}
?>
</div>
 <!-- 
  <div id="footer">
    	<p>
        	Copyright &copy; 2016. Designed by Team 8<br />
           <!~~ 
 <a title="This page validates as XHTML 1.0 Strict" href="http://validator.w3.org/check/referer" class="footerLink"><abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a> | 
            <a title="This page validates as CSS" href="http://jigsaw.w3.org/css-validator/check/referer" class="footerLink"><abbr title="Cascading Style Sheets">CSS</abbr></a>
 ~~>
        </p>
 -->
    </div>
    </body>
</html>