<html>
<body>
<?php
//include('config.php');
session_start();
require 'doctorSession.php';
require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	echo "No Connection to DB";
} 
if(isset($_GET['Edit']))
{
$ReportID=$_GET['Edit'];
//echo $ReportID;
$_SESSION['ReportID'] = $ReportID;
if(isset($_POST['submit']))
{
$Description=$_POST['Description'];
$query3=mysqli_query($connection,"update report set Description='$Description' where ReportID='$ReportID'");
if($query3)
{
header('location:doctor.php');
}
}
$query1=mysqli_query($connection, "select * from report where ReportID='$ReportID'");
$query2=mysqli_fetch_array($query1);
?>
<form method="post" action="">
Description:<input type="text" name="Description" value="<?php echo $query2['Description']; ?>" /><br /><br />

<br />
<input type="submit" name="submit" value="update" />
</form>
<?php
}
?>
</body>
</html>