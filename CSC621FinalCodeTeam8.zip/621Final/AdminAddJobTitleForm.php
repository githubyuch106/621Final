<?php
session_start();
require 'adminSession.php';
?>
<div class="logo">
            	<a href=""><img src="/621Final/images/Saint_Joseph's_University_seal.png" alt="" width="80" height="80" /></a> Team 8<br><span>Hospital Database Management</span>
            	
            </div>
<style>
.logo {
	margin-left: 0px;
	margin-top: 10px;
	padding-left: 5px;
	padding-right:5px;
	border-radius: 10px;
	background-color: #98B8F3;	
	margin-right: 50px;
	}
.body{
margin-left: 50px;
}
.content{
font-family: fantasy;
}
</style>
<?php

?>

<!DOCTYPE html>
<html>

<body>

<h2>New Job Title</h2>

<form  method = "POST" action="AdminAddJobTitle.php" enctype="multipart/form-data">


  <div class="container">
  

    <label><b>Job Title</b></label>
    <input type="text" placeholder="Enter New Job Title" name="JobTitle" required>
        <br></br>

		
		
		
    <button type="submit">Save</button>
	<br></br>
  </div>
  
	
 
</form>




</body>
</html>

