<?php
session_start();
require 'adminSession.php';

require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	echo "No Connection to DB";
} 
if (isset($_GET['Delete']))
{
	
	$EmpID = $_GET['Delete'];
	
	
	$que =  " DELETE FROM `employee` WHERE EmpID = '$EmpID'";
    $record = mysqli_query($connection, $que);
	echo "<meta http-equiv='refresh' content = '0;url=AdminListEmployee.php'>"; 
}
//iterate over all the rows
if($record === FALSE){
echo $record;
}
?>