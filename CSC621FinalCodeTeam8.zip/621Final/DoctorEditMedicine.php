<html>
<body>
<?php
//include('config.php');
session_start();
require 'doctorSession.php';
require 'common.php';
$connection = new mysqli($localhost , $dusername , $dpassword,$database);
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_GET['Edit']))
{
$MedicineID=$_GET['Edit'];
echo $MedicineID;
$_SESSION['MedicineID'] = $MedicineID;
if(isset($_POST['submit']))
{
$Treatment=$_POST['Treatment'];
$query3=mysqli_query($connection,"update medicine set Treatment='$Treatment' where MedicineID='$MedicineID'");
if($query3)
{
header('location:doctor.php');
}
}
$query1=mysqli_query($connection,"select * from medicine where MedicineID='$MedicineID'");
$query2=mysqli_fetch_array($query1);
?>
<form method="post" action="">
Treatment:<input type="text" name="Treatment" value="<?php echo $query2['Treatment']; ?>" /><br /><br />

<br />
<input type="submit" name="submit" value="update" />
</form>
<?php
}
?>
</body>
</html>